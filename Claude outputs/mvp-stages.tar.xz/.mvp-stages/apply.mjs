/**
 * Applies one Sprint 1 stage to the working tree (copies its files, removes deleted ones).
 * It never stages or commits anything: you review the changes and commit them yourself.
 *
 * Usage (from the repository root):  node .mvp-stages/apply.mjs 04
 */
import { cpSync, existsSync, readFileSync, readdirSync, rmSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const stagesDir = dirname(fileURLToPath(import.meta.url));
const repoRoot = dirname(stagesDir);
const stage = process.argv[2]?.padStart(2, '0');
const stageDir = stage && join(stagesDir, stage);

if (!stage || !existsSync(join(stageDir, 'files'))) {
  const available = readdirSync(stagesDir).filter((name) => /^\d{2}$/.test(name));
  console.error(`Usage: node .mvp-stages/apply.mjs <stage>   (stages: ${available.join(', ')})`);
  process.exit(1);
}
if (!existsSync(join(repoRoot, '.git'))) {
  console.error('Run this from the football-stats repository root.');
  process.exit(1);
}

// Copy new and changed files over the working tree
const listFiles = (dir, prefix = '') =>
  readdirSync(dir, { withFileTypes: true }).flatMap((entry) =>
    entry.isDirectory()
      ? listFiles(join(dir, entry.name), `${prefix}${entry.name}/`)
      : [`${prefix}${entry.name}`],
  );
const files = listFiles(join(stageDir, 'files'));
cpSync(join(stageDir, 'files'), repoRoot, { recursive: true, force: true });

// Remove files this stage deletes
const deleted = readFileSync(join(stageDir, 'deleted.txt'), 'utf8').split('\n').filter(Boolean);
for (const file of deleted) rmSync(join(repoRoot, file), { force: true });

console.log(`Stage ${stage}: ${files.length} file(s) written, ${deleted.length} removed.`);
console.log(`Commit message: .mvp-stages/${stage}/message.txt`);
